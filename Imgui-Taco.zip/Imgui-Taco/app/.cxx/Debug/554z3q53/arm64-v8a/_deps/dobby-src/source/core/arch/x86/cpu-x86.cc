#include "platform_detect_macro.h"
#if defined(TARGET_ARCH_IA32) || defined(TARGET_ARCH_X64)

#include "cpu-x86.h"

X86CpuInfo::X86CpuInfo() {

}

#endif