#pragma once

#include "dobby/dobby_internal.h"

#include "core/arch/arm64/constants-arm64.h"

#if 0
namespace zz {
namespace arm64 {
void GenRelocateCodeAndBranch(void *buffer, CodeMemBlock *origin, CodeMemBlock *relocated);
} // namespace arm64
} // namespace zz
#endif