#include "dobby/common.h"

void hexdump(const uint8_t *bytes, size_t len);