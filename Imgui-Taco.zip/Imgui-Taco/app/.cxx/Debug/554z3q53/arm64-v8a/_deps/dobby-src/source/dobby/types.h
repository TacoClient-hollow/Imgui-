#pragma once

#include <stdint.h>

typedef unsigned char byte_t;
typedef unsigned int uint;

#ifndef NULL
#define NULL 0
#endif
