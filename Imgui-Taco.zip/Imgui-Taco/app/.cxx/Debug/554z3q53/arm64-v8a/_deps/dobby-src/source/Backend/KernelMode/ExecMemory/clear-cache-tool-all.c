void ClearCache(void *start, void *end) {
  return;
}
