#pragma once

int DobbyCodePatch(void *address, uint8_t *buffer, uint32_t buffer_size);