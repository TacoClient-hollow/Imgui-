#include "imgui.h"
#include <string>
#include <jni.h>

// Function to get clipboard content via JNI
std::string GetClipboardText(JNIEnv* env, jobject context) {
    if (!env || !context) return "Invalid JNI context.";

    jclass clipboardManagerClass = env->FindClass("android/content/ClipboardManager");
    if (!clipboardManagerClass) return "ClipboardManager not found.";

    jmethodID getService = env->GetStaticMethodID(env->FindClass("android/content/Context"),
                                                 "getSystemService",
                                                 "(Ljava/lang/String;)Ljava/lang/Object;");
    if (!getService) return "getSystemService not found.";

    jstring clipboardService = env->NewStringUTF("clipboard");
    jobject clipboardManager = env->CallStaticObjectMethod(env->FindClass("android/content/Context"),
                                                          getService, clipboardService);
    env->DeleteLocalRef(clipboardService);

    if (!clipboardManager) return "Clipboard service unavailable.";

    jmethodID getPrimaryClip = env->GetMethodID(clipboardManagerClass, "getPrimaryClip", "()Landroid/content/ClipData;");
    if (!getPrimaryClip) return "getPrimaryClip not found.";

    jobject clipData = env->CallObjectMethod(clipboardManager, getPrimaryClip);
    if (!clipData) return "Clipboard is empty.";

    jclass clipDataClass = env->GetObjectClass(clipData);
    jmethodID getItemAt = env->GetMethodID(clipDataClass, "getItemAt", "(I)Landroid/content/ClipData$Item;");
    jobject item = env->CallObjectMethod(clipData, getItemAt, 0);

    if (!item) return "Clipboard item not found.";

    jclass itemClass = env->GetObjectClass(item);
    jmethodID coerceToText = env->GetMethodID(itemClass, "coerceToText", "(Landroid/content/Context;)Ljava/lang/CharSequence;");
    jobject text = env->CallObjectMethod(item, coerceToText, context);

    if (!text) return "Clipboard text is empty.";

    const char* result = env->GetStringUTFChars((jstring)text, nullptr);
    std::string clipboardText = result ? result : "Empty clipboard.";
    env->ReleaseStringUTFChars((jstring)text, result);

    return clipboardText;
}
